<!-- end content -->
</div> <!-- /.wrap -->
<div id="footer" class="bg-black">
      <div class="container">
            <p class="text-muted" align="center"><br>&copy; <?php echo date("Y"); ?> Developed by J. van Marion /
            <a href="https://github.com/nlmaca" target="_blank"><i class="fa fa-github-alt fa-lg">&nbsp;&nbsp;</i></a>
                   <a href="https://nl.linkedin.com/in/jeroenvanmarion" target="_blank"><i class="fa fa-linkedin-square fa-lg">&nbsp;&nbsp;</i></a>
            <br>Version 2.3</p>
      </div>
</div>


<script src="<?php echo $DOCUMENT_ROOT; ?>/assets/bootstrap.min.js"></script>
</body>
</html>